
  # Recommended Worker Carousel

  This is a code bundle for Recommended Worker Carousel. The original project is available at https://www.figma.com/design/efkvmHp25I2NZBWiSkgLpN/Recommended-Worker-Carousel.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  