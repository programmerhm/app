import { SearchResultCard } from "./SearchResultCard";

interface SearchResultsProps {
  view: "grid" | "list";
}

const searchResultsData = [
  {
    id: 1,
    name: "Arun Kumar",
    profession: "Welder",
    rating: 4.9,
    photo: "https://images.unsplash.com/photo-1586333109867-812586269a58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWxkZXIlMjBwcm9mZXNzaW9uYWwlMjB3b3JrZXJ8ZW58MXx8fHwxNzU3OTMyNTgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Welding", "Metal Work", "Fabrication"],
    price: 300
  },
  {
    id: 2,
    name: "Priya Singh",
    profession: "Mechanic",
    rating: 4.7,
    photo: "https://images.unsplash.com/photo-1545732870-5dced7323d26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWNoYW5pYyUyMHRlY2huaWNpYW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU3OTMyNTgzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Auto Repair", "Engine Work", "Diagnostics"],
    price: 250
  },
  {
    id: 3,
    name: "Rakesh Sharma",
    profession: "Carpenter",
    rating: 4.8,
    photo: "https://images.unsplash.com/photo-1740754699699-c8b4b1635faf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJwZW50ZXIlMjB3b29kd29ya2VyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1NzkzMjU4Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Woodwork", "Furniture", "Installation"],
    price: 200
  },
  {
    id: 4,
    name: "Sunita Devi",
    profession: "Cleaner",
    rating: 4.6,
    photo: "https://images.unsplash.com/photo-1701651545983-c3b357a8387f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbmVyJTIwamFuaXRvciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTc5MzI1ODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["House Cleaning", "Office Cleaning", "Deep Clean"],
    price: 150
  }
];

export function SearchResults({ view }: SearchResultsProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-foreground">Search Results ({searchResultsData.length})</h2>
      </div>
      
      <div className={view === "grid" ? "grid grid-cols-2 gap-4" : "space-y-4"}>
        {searchResultsData.map((worker) => (
          <SearchResultCard
            key={worker.id}
            name={worker.name}
            profession={worker.profession}
            rating={worker.rating}
            photo={worker.photo}
            skills={worker.skills}
            price={worker.price}
          />
        ))}
      </div>
    </div>
  );
}