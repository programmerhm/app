import { X } from "lucide-react";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Slider } from "./ui/slider";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "./ui/sheet";

interface FiltersSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const skills = [
  "Welding",
  "Painting", 
  "Electrical Work",
  "Plumbing",
  "Construction",
  "Carpentry",
  "Cleaning",
  "Mechanic"
];

export function FiltersSidebar({ isOpen, onClose }: FiltersSidebarProps) {
  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-80">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle>Filters</SheetTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </SheetHeader>
        
        <div className="space-y-6 mt-6">
          {/* Skills Multi-Select */}
          <div className="space-y-3">
            <Label className="text-foreground">Skills</Label>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {skills.map((skill) => (
                <div key={skill} className="flex items-center space-x-2">
                  <Checkbox id={skill} />
                  <Label htmlFor={skill} className="text-sm">
                    {skill}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="space-y-3">
            <Label className="text-foreground">Price Range (₹/hour)</Label>
            <div className="px-2">
              <Slider
                defaultValue={[100, 500]}
                max={1000}
                min={50}
                step={50}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-1">
                <span>₹50</span>
                <span>₹1000</span>
              </div>
            </div>
          </div>

          {/* Rating Filter */}
          <div className="space-y-3">
            <Label className="text-foreground">Minimum Rating</Label>
            <div className="flex items-center space-x-2">
              <Checkbox id="rating-4" defaultChecked />
              <Label htmlFor="rating-4" className="text-sm">
                4.0+ stars
              </Label>
            </div>
          </div>

          {/* Apply Filters Button */}
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Apply Filters
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}