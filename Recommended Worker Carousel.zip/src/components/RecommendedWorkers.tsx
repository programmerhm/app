import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "./ui/carousel";
import { WorkerCard } from "./WorkerCard";

const workerData = [
  {
    id: 1,
    name: "Raj",
    profession: "Painter",
    rating: 4.8,
    photo: "https://images.unsplash.com/photo-1688372199140-cade7ae820fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYWludGVyJTIwd29ya2VyJTIwdW5pZm9ybXxlbnwxfHx8fDE3NTc4NzY1NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    matchesSkills: true
  },
  {
    id: 2,
    name: "Maria",
    profession: "Electrician",
    rating: 4.9,
    photo: "https://images.unsplash.com/photo-1467733238130-bb6846885316?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2lhbiUyMHRlY2huaWNpYW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU3OTMyMzk1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    matchesSkills: true
  },
  {
    id: 3,
    name: "James",
    profession: "Construction Worker",
    rating: 4.7,
    photo: "https://images.unsplash.com/photo-1672748341520-6a839e6c05bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTc4NTEwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    matchesSkills: true
  },
  {
    id: 4,
    name: "Sarah",
    profession: "Plumber",
    rating: 4.8,
    photo: "https://images.unsplash.com/photo-1665436035665-d7dad9086ee2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b3JrZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTc4Mzg5MDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    matchesSkills: true
  }
];

export function RecommendedWorkers() {
  return (
    <div className="w-full space-y-4">
      {/* Section Header */}
      <h2 className="text-black">Recommended for You</h2>
      
      {/* Workers Carousel */}
      <Carousel
        opts={{
          align: "start",
        }}
        className="w-full"
      >
        <CarouselContent className="-ml-2 md:-ml-4">
          {workerData.map((worker) => (
            <CarouselItem key={worker.id} className="pl-2 md:pl-4 basis-auto">
              <WorkerCard
                name={worker.name}
                profession={worker.profession}
                rating={worker.rating}
                photo={worker.photo}
                matchesSkills={worker.matchesSkills}
              />
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
    </div>
  );
}