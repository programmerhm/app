import { Search, SlidersHorizontal } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface SearchBarProps {
  onFiltersClick: () => void;
}

export function SearchBar({ onFiltersClick }: SearchBarProps) {
  return (
    <div className="flex items-center space-x-3 p-4 bg-white border-b border-border">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          placeholder="e.g., Welder in Delhi"
          className="pl-10 text-black placeholder:text-black bg-input-background border-border"
        />
      </div>
      <Button
        variant="outline"
        size="icon"
        onClick={onFiltersClick}
        className="h-10 w-10"
      >
        <SlidersHorizontal className="h-5 w-5" />
      </Button>
    </div>
  );
}