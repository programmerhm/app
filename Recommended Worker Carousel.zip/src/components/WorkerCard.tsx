import { Star } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface WorkerCardProps {
  name: string;
  profession: string;
  rating: number;
  photo: string;
  matchesSkills?: boolean;
}

export function WorkerCard({ name, profession, rating, photo, matchesSkills = true }: WorkerCardProps) {
  return (
    <Card className="w-64 flex-shrink-0">
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Worker Photo */}
          <div className="w-full h-40 rounded-lg overflow-hidden">
            <ImageWithFallback
              src={photo}
              alt={`${name} - ${profession}`}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Worker Info */}
          <div className="space-y-2">
            <h3 className="text-foreground">{name} - {profession}</h3>
            
            {/* Rating */}
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-foreground">{rating}</span>
            </div>

            {/* Skills Badge */}
            {matchesSkills && (
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                Matches Your Skills
              </Badge>
            )}
          </div>

          {/* Contact Button */}
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Contact
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}