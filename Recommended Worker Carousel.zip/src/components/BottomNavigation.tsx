import { Search, Home, MessageCircle, User } from "lucide-react";

export function BottomNavigation() {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border">
      <div className="flex items-center justify-around h-16">
        <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground">
          <Home className="h-6 w-6" />
          <span className="text-xs">Home</span>
        </button>
        
        <button className="flex flex-col items-center justify-center space-y-1 text-blue-600">
          <Search className="h-6 w-6" />
          <span className="text-xs">Search</span>
        </button>
        
        <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground">
          <MessageCircle className="h-6 w-6" />
          <span className="text-xs">Messages</span>
        </button>
        
        <button className="flex flex-col items-center justify-center space-y-1 text-muted-foreground">
          <User className="h-6 w-6" />
          <span className="text-xs">Profile</span>
        </button>
      </div>
    </div>
  );
}