import { Star } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface SearchResultCardProps {
  name: string;
  profession: string;
  rating: number;
  photo: string;
  skills: string[];
  price: number;
}

export function SearchResultCard({ name, profession, rating, photo, skills, price }: SearchResultCardProps) {
  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Worker Photo */}
          <div className="w-full h-48 rounded-lg overflow-hidden">
            <ImageWithFallback
              src={photo}
              alt={`${name} - ${profession}`}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Worker Info */}
          <div className="space-y-2">
            <h3 className="text-foreground">{name}</h3>
            <p className="text-muted-foreground text-sm">{profession}</p>
            
            {/* Rating */}
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-foreground text-sm">{rating}</span>
            </div>

            {/* Skills */}
            <div className="flex flex-wrap gap-1">
              {skills.slice(0, 2).map((skill) => (
                <Badge key={skill} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {skills.length > 2 && (
                <Badge variant="secondary" className="text-xs">
                  +{skills.length - 2}
                </Badge>
              )}
            </div>

            {/* Price */}
            <p className="text-foreground">₹{price}/hour</p>
          </div>

          {/* Contact Button */}
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Contact
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}